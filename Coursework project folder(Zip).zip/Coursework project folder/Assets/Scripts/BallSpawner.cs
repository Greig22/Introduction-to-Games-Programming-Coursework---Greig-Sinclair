﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// This class defines a component which can spawn new game objects by creating copies
// of a template game object which exists in the scene.

class BallSpawner : MonoBehaviour
{
    // This variable is set in the Inspector to an inactive Text object containing
    // the text to display when the game is over.
    public Text YouLose = null;

    public Ball BallTemplate = null;

    // The total number of balls to spawn when the game is started. This value can be
    // overridden in the Inspector.
    public int totalBalls = 1;
    
    // List to keep track of all balls spawned by this script.
    List<Ball> BallList = new List<Ball>();

    void Start()
    {
        for (int count = 0; count < totalBalls; count++)
        {
            SpawnBall(BallTemplate);
        }
    }

    void SpawnBall(Ball TemplateToCopy)
    {
        // Clone the template game object
        Ball BallClone = Instantiate(BallTemplate);

        // Move the new ball clone to the ball spawner's position
        BallClone.transform.position = transform.position;

        // Set the size of the ball clone to a random number
        BallClone.size = Random.Range(0.5f, 2.0f);

        // Generate a random direction for the ball clone
        int angle = Random.Range(-30, 30);
        if (Random.Range(0, 100) < 50)
        {
            angle += 180;
        }
        BallClone.SetDirection(angle);

        // Activate the new ball clone
        BallClone.gameObject.SetActive(true);

        // Add the new ball clone to the list of balls
        BallList.Add(BallClone);

    }

    public void DespawnBall(Ball BallToDespawn)
    {
        // Remove the ball from the list of balls
        BallList.Remove(BallToDespawn);

        // Destroy the ball game object
        Destroy(BallToDespawn.gameObject);

        // Activate You Lose text screen
        if (BallList.Count == 0)
        {
            YouLose.gameObject.SetActive(true);
        }

    }

}
