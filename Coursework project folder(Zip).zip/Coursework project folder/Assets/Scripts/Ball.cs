﻿using System.Collections.Generic;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

class Ball : MonoBehaviour

{
    public BallSpawner spawner = null;

    // Setting the ball's default variables to be later randomised 
    public float size = 1.0f;
    float speed = 0.2f;
    int score = 10;
    float directionX = 1.0f;
    float directionY = 0.5f;

    // The total number of bricks as you start the game
    public int numberofbricks = 13;

    // This variable is set in the Inspector to an inactive Text object containing
    // the text to display when the game is over.
    public Text YouWin = null;

    AudioSource Audio;

    // This method allows an audio file to play whenever a brick is hit by the ball
    void Start()
    {
        Audio = GetComponent<AudioSource>();
    }

    protected virtual void FixedUpdate()
    {
        Vector3 scale = new Vector3();
        scale.x = size;
        scale.y = size;
        transform.localScale = scale;

        Vector3 position = transform.localPosition;
        position.x += speed * directionX;
        position.y += speed * directionY;
        transform.localPosition = position;
    }


    // This method is run by Unity whenever the ball hits something. The 'other' parameter
    // contains details about the collision, including the other game object that was hit.

    void OnCollisionEnter2D(Collision2D other)

    {

        // This switch statement compares the other game object's tag to each of the cases
        // within the switch. If the tag matches one of the cases then all the statements 
        // underneath that case will be run, until the break statement.

        switch (other.gameObject.tag)
        {
            case "Left Right Walls":
                directionX = -directionX; // Invert the direction horizontally
                break;

            case "TopWall":
            case "Bat":
                directionY = -directionY; // Invert the direction vertically
                break;

            case "BottomWall":
                spawner.DespawnBall(this); // Destroy the ball
                break;

            case "Brick":
                directionY = -directionY; // Invert the direction vertically
                Destroy(other.gameObject); // Destroy Brick
                numberofbricks = numberofbricks - 1; // Decrease the number of bricks
                Audio.Play(); // Play audio file
                break;
        }

        if (numberofbricks == 0)
        {
            YouWin.gameObject.SetActive(true); // Activate win text screen
        }
    }
    // Set the direction of the ball, in degrees.
    public void SetDirection(int angleInDegrees)
    {
        float angleInRadians = angleInDegrees * Mathf.Deg2Rad;
        directionX = Mathf.Cos(angleInRadians);
        directionY = Mathf.Sin(angleInRadians);
    }


}