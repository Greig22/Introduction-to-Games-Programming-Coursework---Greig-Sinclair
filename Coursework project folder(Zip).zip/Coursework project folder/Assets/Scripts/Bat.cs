﻿using UnityEngine;

using UnityEngine.UI;

class Bat : MonoBehaviour

{
    // These variables set the Keys which will be used later to allow the player to move the bat 
    // as well as determining the default speed and direction.
    public KeyCode moveLeftKey = KeyCode.LeftArrow;
    public KeyCode moveRightKey = KeyCode.RightArrow;
    bool canMoveLeft = true;
    bool canMoveRight = true;
    public float speed = 0.2f;
    float direction = 0.0f;

    void FixedUpdate()

    {
        Vector3 position = transform.localPosition;
        position.x += speed * direction;
        transform.localPosition = position;
    }

    // This method determines if the bat is obstructed by a wall and therfore stops the player
    // from moving in that direction
    void OnCollisionEnter2D(Collision2D other)
    {
        switch (other.gameObject.name)
        {
            case "LeftWall":
                canMoveLeft = false; // Bat cant move left
                break;

            case "RightWall":
                canMoveRight = false; // Bat cant move right
                break;
        }
    }

    // This method determines if the bat has moved away from the wall and therefore
    // the player can move in that direction once again
    void OnCollisionExit2D(Collision2D other)
    {
        switch (other.gameObject.name)
        {
            case "LeftWall":
                canMoveLeft = true; // Bat can move left
                break;

            case "RightWall":
                canMoveRight = true; // Bat can move right
                break;
        }
    }
    // This method moves allows the player to move the bat 
    void Update()
    {
        bool isLeftPressed = Input.GetKey(moveLeftKey);
        bool isRightPressed = Input.GetKey(moveRightKey);

        if (isLeftPressed && canMoveLeft)
        {
            // Set the direction of the bat using this key
            direction = -1.5f;
        }
        else if (isRightPressed && canMoveRight)
        {
            // Set the direction of the bat using this key
            direction = 1.5f;
        }
        else
        {
            // Set the direction of the bat when not pushing any key
            direction = 0.0f;
        }
    }

}
